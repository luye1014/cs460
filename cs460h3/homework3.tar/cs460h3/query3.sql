select distinct fname, dependent_name from mccann.employee, mccann.dependent;
