select * from mccann.employee where dno=5;
